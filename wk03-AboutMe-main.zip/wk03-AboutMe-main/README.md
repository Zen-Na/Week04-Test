# wk03-AboutMe

## What's This?
In this repository, it contains the .html, .css and .png files for my About Me website done for ID course for Week 3!

## URL for the github repository
https://github.com/Zen-Na/wk03-AboutMe/upload/main

## Credits
w3schools for guidance/tips used!
Good friend Simon for guiding me as well!
